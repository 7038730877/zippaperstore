<style>
body
{
background-image:url("boot/image/bg1.jpg");
}
</style>