 <link href="boot/css/bootstrap.min.css" rel="stylesheet">
    <link href="boo/tcss/font-awesome.min.css" rel="stylesheet">
    <link href="boot/css/prettyPhoto.css" rel="stylesheet">
    <link href="boot/css/price-range.css" rel="stylesheet">
    <link href="boot/css/animate.css" rel="stylesheet">
	<link href="boot/css/main.css" rel="stylesheet">
	<link href="boot/css/responsive.css" rel="stylesheet">
    <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->       
    <link rel="shortcut icon" href="images/ico/favicon.ico">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="images/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="images/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="images/ico/apple-touch-icon-57-precomposed.png">
</head><!--/head-->
  <script src="boot/js/jquery.js"></script>
	<script src="boot/js/bootstrap.min.js"></script>
	<script src="boot/js/jquery.scrollUp.min.js"></script>
	<script src="boot/js/price-range.js"></script>
    <script src="boot/js/jquery.prettyPhoto.js"></script>
    <script src="boot/js/main.js"></script>
	
	
	
	
	
	
	
	
	
	
