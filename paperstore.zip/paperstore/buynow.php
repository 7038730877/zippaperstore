<?php
include("configi.php");?>
<head>
        
        <script type='text/javascript'>
function notEmpty(elem, helperMsg){
	if(elem.value.length == 0){
		alert(helperMsg);
		elem.focus();
		return false;
	}
	return true;
}
</script>
        <link rel="stylesheet" href="validation/css/validationEngine.jquery.css" type="text/css"/>
        <link rel="stylesheet" href="validation/css/template.css" type="text/css"/>
        <script src="validation/js/jquery-1.6.min.js" type="text/javascript">
        </script>
        <script src="validation/js/languages/jquery.validationEngine-en.js" type="text/javascript" charset="utf-8">
        </script>
        <script src="validation/js/jquery.validationEngine.js" type="text/javascript" charset="utf-8">
        </script>
        <script>
            jQuery(document).ready(function(){
                // binds form submission and fields to the validation engine
                jQuery("#formID").validationEngine();
            });
            
            /**
             *
             * @param {jqObject} the field where the validation applies
             * @param {Array[String]} validation rules for this field
             * @param {int} rule index
             * @param {Map} form options
             * @return an error string if validation failed
             */
            function checkHELLO(field, rules, i, options){
                if (field.val() != "HELLO") {
                    // this allows to use i18 for the error msgs
                    return options.allrules.validate2fields.alertText;
                }
            }
        </script>
    </head>
        <form id="formID" class="formular" method="post" action="">

<?php

if(isset($_POST["btnbuy"]))
{
	extract($_POST);
	$qry=mysqli_query($con,"insert into tblbuy (fname,email,address,city,state,contry,pcode,mobile) value('$txtname','$txtemail','$txtadd','$txtcity','$txtstate','$txtcon','$txtpostal','$txtmob')");
	header("location:info.php");
	
	
	
}
?>
<div align="center">
   
	<div class='panel panel-primary' class="col-md-6 pull-center">
            <div class='panel-heading'>
              <h3 class='panel-title'>Shiping And Biling Details</h3>
            </div>
 <div class='panel-body'>
	  <form method="post">
<table >

<tr>
<td>
Full Name:
</td>
<td>
<input type="text" required name="txtname"/>
</td>
</tr>
<tr>
<td>
Email:
</td>
<td>
<input type="email" required name="txtemail"/>
</td>
</tr>
<tr>
<td>
Address:
</td>
<td>
<textarea required name="txtadd" /></textarea>
</td>
</tr>
<tr>
<td>
City
</td>
<td>
<input type="text" required name="txtcity"/>
</td>
</tr>
<tr>
<td>
State:
</td>
<td>
<input type="text" required name="txtstate"/>
</td>
</tr>
<tr>
<td>
Contry:
</td>
<td>
<input type="text" name="txtcon"/>
</td>
</tr>
<tr>
<td>
Postal Code:
</td>
<td>
<input type="text" required class="form-control" name="txtpostal"/>
</td>
</tr>
<tr>
<td>
Mobile:
</td>
<td>

		<input value="" class="validate[required,minSize[10],maxSize[12]] text-input"   type="number" id="minsize" name="txtmob" >	
</td>
</tr>
<tr>
<td>
<input type="submit" name="btnbuy" value="Submit" class="btn btn-primary" />
</td>
</tr>



</table>

	  </form>
	
</div>
</div>
</div>



