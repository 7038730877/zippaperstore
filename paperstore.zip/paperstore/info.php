<?php
session_start();

 
 include("config.php");?>
  

	
    
 


<?php

 $qry=mysql_query("select * from tblbuy where email='".$_SESSION["email"]."'");
 while($r=mysql_fetch_array($qry))
 {
	 extract($r);
	 ?>
	 <table align="center">
	 <h2 align="center"><font color="#CC3300">Shiping And Billing Details</font></h2>
	 <tr>
   <td> Name: <?=$a=$r["fname"]?></td></tr>
  <tr> <td> Email: <?=$a=$r["email"]?></td> </tr>
   <tr> <td> Address: <?=$a=$r["address"]?></td> </tr>
   <tr> <td> City: <?=$a=$r["city"]?></td> </tr>
   <tr> <td> State: <?=$a=$r["state"]?></td> </tr>
   <tr> <td> Contry: <?=$a=$r["contry"]?></td> </tr>
   <tr> <td> Postal Code: <?=$a=$r["pcode"]?></td> </tr>
    <tr><td> Mobile No: <?=$a=$r["mobile"]?></td>
   </tr>
   <tr>
   <td>
   <a href="continue.php">
      <input type="submit" value="continue" class="btn btn-warning" name="btncon" /></td></a>
   </tr>
   
   </table>
 <?php
 }