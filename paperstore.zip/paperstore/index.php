

<?php

include("head.php");
?>

<?php include("header.php");?>
<?php include("silder.php");?>
<?php include("footer.php");?>

