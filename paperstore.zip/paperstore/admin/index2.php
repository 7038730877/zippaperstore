<script type="text/javascript" src="ckeditor/ckeditor.js"></script>
<?php 
 include("head.php"); 
include("leftcall.php");
include("config.php");?>

<?php
require_once("dbcontroller.php");
$db_handle = new DBController();
$query ="SELECT * FROM categories";
$results = $db_handle->runQuery($query);
?>

<script src="ajaxdropdown.js" type="text/javascript"></script>
<script>
function getState(val) {
	$.ajax({
	type: "POST",
	url: "get_state.php",
	data:'country_id='+val,
	success: function(data){
		$("#state-list").html(data);
	}
	});
}

function selectCountry(val) {
$("#search-box").val(val);
$("#suggesstion-box").hide();
}
</script>
<?php
if(isset($_POST['btnsave']))
{
	extract($_POST);
	mysql_query("");
}
?>
<html>

<body >

		
<div align="center">
 <div class='panel panel-primary' col-md-3>
            <div class='panel-heading'>
              <h3 class='panel-title'>Add Product</h3>
            </div>
 <div class='panel-body'>
<form action="upload.php" method="post" enctype="multipart/form-data" >
<table class="table-condensed" align="center">
<tr>
<td>
Title:
</td>
<td>
<input type="text" name="txttitle" id="txttitle" class="form-control">
</td>
</tr>

<tr>

<div class="frmDronpDown">
<div class="row">

<td>

<label>Category:</label><br/>
<select name="cmb" id="country-list" class="demoInputBox" class="form-control" class="form-control" onChange="getState(this.value);">
<option value="">Select Category</option>
<?php
foreach($results as $country) {
?>
<option value="<?php echo $country["id"]; ?>"><?php echo $country["cname"]; ?></option>
<?php
}
?>
</select>

</td>
</div>




<div class="row">
<td>
<label>Subcategory:</label><br/>

<select name="sid" id="state-list" class="form-control" class="demoInputBox">
<option value="">Select Subcategory</option>
</select>
</td>
</div>

</div>
</tr>

<tr>
<td>
    Select image to upload:
    
</td>
<td>
    <input type="file" name="fileToUpload" class="form-control" id="fileToUpload">
</td>
<tr>
<td>
   Add Description:	
</td>
<td>
	
	<textarea class="ckeditor" name="txtarea"></textarea>
</td>
</tr>
<tr>
<td>
   Add Price:	
</td>
<td>
	<input type="text" name="txtprice" class="form-control" id="txtprice">
</td>
</tr>
<tr>
<td>
   Add Quantity:	
</td> 
<td>
	<input type="text"  name="txtqty" class="form-control" id="txtqty">
</td>
</tr>

<tr>
<td align="center">
    <input type="submit" value="Upload Image" name="submit" class="btn btn-warning">
</td>
</tr>
</tr>

</table>
</form>
 </div>
 </div>
 </div>
</body>
</html>





