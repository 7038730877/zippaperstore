<?php
 include("head.php");

 include("config.php");
error_reporting(null);
?>
<?php
 if(isset($_POST['btnupdate']))
{
extract($_POST);
$qry=mysql_query("update tblupload1 set title='$txttit',pdescription='$txtdnm',pprice='$txtbody',qty='$txtqty' where id=".$_GET['id']);
if($qry==1)
{
?>
<script>alert("Records updated Sucessfully");</script>
<?php
}
}
else if(isset($_POST['del']))
{
extract($_POST);
$qry=mysql_query("delete from tblupload1 where id=".$_GET['id']);
if($qry==1)
{
?>
<script>alert("Records deleted Sucessfully");</script>
<?php
}
}

if($_GET['id'])
{
$qry=mysql_query( "select * from tblupload1 where id=".$_GET['id']);
if($row=mysql_num_rows($qry)==1)
{$row=mysql_fetch_array($qry);

extract($row);
}

}
?>
<html>
  <div class="col-lg-12">
   <div class="panel panel-red">
   <div class="panel-heading">
    Asanas information Form</div>
    <div class="panel-body pan">


<form method="post" enctype="multipart/form-data" >
<table class="table table-condensed">
<tr>
<tr>
<Td>
Title :
</Td>
<td>
<input type="text" name="txttit" class="form-control" value="<?=$title?>" required />
</td>
</tr>


 <tr>
<Td>
Discription:
</Td>
<td>
<input type="text" name="txtdnm" class="form-control" value="<?=$pdescription?>" required />
</td>
</tr>
   
 

  <tr>
<Td>
Price :
</Td>
<td>
<input type="text" name="txtbody" class="form-control" value="<?=$pprice?>" required />
</td>
</tr>
  <tr>
<Td>
Quantity:
</Td>
<td>
<input type="text" name="txtqty" class="form-control" value="<?=qty?>" required />

</td>
</tr>

<tr>
<td colspan="2" align="center">

<input type="submit" class="btn btn-warning" name="btnupdate" value="Edit" />
<input type="submit" class="btn btn-danger" name="del" value="Delete" />
</tD>
</tr>
</tr>
</table>
</form>
</html>
<table border="2">
<Tr>
<td>
id
</td>
<td>
Title
</td>
<td>
Image 
</td>
<td>
Description
</td><td>
Price 
</td><td>
Quantity
</td><td>
Sid
</td>
</Tr>
<?php
$qry=mysql_query("select * from tblupload1");
while($row=mysql_fetch_array($qry))
{
?>
<tr>
<td><?=$row["id"]?></td>
<td><?=$row["title"]?></td>
<td><img src="<?=$row["path"]?>" height="150px" width="150px"></td>
<td><?=$row["pdescription"]?></td>
<td><?=$row["pprice"]?></td>
<td><?=$row["process"]?></td>
<td><?=$row["qty"]?></td>
<td><?=$row["sid"]?></td>

<td><a  href="addrecord.php?id=<?=$row["id"]?>">select</a></td>
</tr>
<?php
}

?>

</table>

</form>


</html>