<?php
require_once("dbcontroller.php");
$db_handle = new DBController();
$query ="SELECT * FROM categories";
$results = $db_handle->runQuery($query);
?>

<script src="ajaxdropdown.js" type="text/javascript"></script>
<script>
function getState(val) {
	$.ajax({
	type: "POST",
	url: "get_state.php",
	data:'country_id='+val,
	success: function(data){
		$("#state-list").html(data);
	}
	});
}

function selectCountry(val) {
$("#search-box").val(val);
$("#suggesstion-box").hide();
}
</script>
<?php
include("config.php");
include("mylib.php");
$m= new mylib();

if(isset($_POST['btnsave']))
{
	extract($_POST);
	$f= $_POST['id'];
	  $query =$m->runquery("SELECT id FROM categories where cname='$f'");
	  $result=mysql_fetch_array($query);
	  $emp_name=$result['id'];
	  echo $emp_name;
	 $h= $_POST['sid']; 
	  $query1 =$m->runquery("SELECT sid FROM subcategory where sname='$h'");
	  $result=mysql_fetch_array($query1);
	  $emp_name1=$result['sid'];
	  echo $emp_name1;
	mysql_query("insert into merge (id,sid)values('$emp_name','$emp_name1')");
}
?>
  <div id="page-wrapper">
<form method="post">
<div class="frmDronpDown">
<div class="row">
<label>Category:</label><br/>
<select name="country" id="country-list" class="demoInputBox" onChange="getState(this.value);">
<option value="">Select Category</option>
<?php
foreach($results as $country) {
?>
<option value="<?php echo $country["id"]; ?>"><?php echo $country["cname"]; ?></option>
<?php
}
?>
</select>
</div>
<div class="row">
<label>Subcategory:</label><br/>
<select name="sid" id="state-list" class="demoInputBox">
<option value="">Select Subcategory</option>
</select>
</div>
</div>
<input type="submit" name="btnsave">
</form>
</div>

