


 <?php
 session_start();
if($_SESSION["name"]==null)
{
	header("location:alogin.php");
}
?>

<?php
include("head.php");
?>
<?php include("leftcall.php");?>
<?php include("header.php");?>


