<?php
 include("head.php");
 
 include("config.php");
error_reporting(null);
?>

<script language="javascript" type="text/javascript">
        function printDiv(divID) {
            //Get the HTML of div
            var divElements = document.getElementById(divID).innerHTML;
            //Get the HTML of whole page
            var oldPage = document.body.innerHTML;

            //Reset the page's HTML with div's HTML only
            document.body.innerHTML = 
              "<body>" + 
              divElements + "</body>";

            //Print Page
            window.print();

            //Restore orignal HTML
            document.body.innerHTML = oldPage;

          
        }
    </script>


<html>
  <div class="col-lg-12">
   <div class="panel panel-red">
   <div class="panel-heading">
   Customer Record</div>
    <div class="panel-body pan">


<form method="post" enctype="multipart/form-data" action="upload.php">
<input type="button" value="Print " style="color:#000000" class="btn btn-success" onClick="javascript:printDiv('printablediv')" />

<div id="printablediv">

<table class="table table-condensed">
<tr>



</tr>

</table>
</form>
</html>
<table border="2" class="table table-condensed"">
<Tr>
<td>
Name
</td>
<td>
Email
</td>
<td>
Address
</td>
<td>
City
</td>
<td>
State
</td>
<td>
Country
</td>
<td>
Pin Code
</td>
<td>
Mobile Number
</td>


</Tr>
<?php
$qry=mysql_query("select * from tblbuy");
while($row=mysql_fetch_array($qry))
{
?>
<tr>
<td><?=$row["fname"]?></td>
<td><?=$row["email"]?></td>
<td><?=$row["address"]?></td>
<td><?=$row["city"]?></td>
<td><?=$row["state"]?></td>
<td><?=$row["contry"]?></td>
<td><?=$row["pcode"]?></td>
<td><?=$row["mobile"]?></td>





</tr>
</tr>
<?php
}

?>
</div>

</table>

</form>


</html>