<?php
 include("head.php");
 
 include("config.php");
error_reporting(null);
?>
<script language="javascript" type="text/javascript">
        function printDiv(divID) {
            //Get the HTML of div
            var divElements = document.getElementById(divID).innerHTML;
            //Get the HTML of whole page
            var oldPage = document.body.innerHTML;

            //Reset the page's HTML with div's HTML only
            document.body.innerHTML = 
              "<body>" + 
              divElements + "</body>";

            //Print Page
            window.print();

            //Restore orignal HTML
            document.body.innerHTML = oldPage;

          
        }
    </script>

<html>
  <div class="col-lg-12">
   <div class="panel panel-red">
   <div class="panel-heading">
    Product Record</div>
    <div class="panel-body pan">
<input type="button" value="Print" style="color:#000000" class="btn btn-success" onClick="javascript:printDiv('printablediv')" />

<div id="printablediv">
<table class="table table-condensed">
<tr>



</tr>
</table>
</form>
</html>
<table border="2" class="table table-condensed"">
<Tr>
<td>
Id
</td>
<td>
Category
</td>
<td>
sid
</td>
<td>
Subcategory
</td>

</Tr>
<?php
$qry=mysql_query("select * from categories,subcategory");
while($row=mysql_fetch_array($qry))
{
?>
<tr>
<td><?=$row["id"]?></td>
<td><?=$row["cname"]?></td>
<td><?=$row["sid"]?></td>
<td><?=$row["sname"]?></td>





</tr>
</tr>
<?php
}

?>

</table>

</div>



</html>