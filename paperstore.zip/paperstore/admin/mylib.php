<?php
class mylib {
	public $conn=null;
	
	//constructor 
	public function mylib()
	{
		$this->conn=mysqli_connect("localhost", "root", "", "storedb") or die(mysqli_connect_error());
		mysqli_set_charset($this->conn,'utf8');		
	}
	//encode
	public function urlfriendlyencode($string_url)
	{
		$string = urlencode($string_url);
		return $string;
	}
	//decode
	public function urlfriendlydecode($string_url)
	{
		$string = urldecode($string_url);
		return $string;
	}
	//runquery
    public function runquery($qry)
    {
        $q = mysqli_query($this->conn,$qry);
        return $q;
    }
	//fillcombo
	public function fillcombo($query='',$val='',$disp='',$def='',$first='Select')
	{
		if($first=='All')
			echo "<option value='All'>All</option>";
		else if($first=='Select')
			echo "<option value=''>Select</option>";
		$q = mysqli_query($this->conn,$query);
		while($r = mysqli_fetch_assoc($q))
		{
			if($r[$val]==$def)
				echo "<option selected value='".$r[$val]."'>".$r[$disp]."</option>";
			else
				echo "<option value='".$r[$val]."'>".$r[$disp]."</option>";
		}
	}
	//makecheck
	public function makecheck($source, $checked, $name, $col=3)
	{
		$source_array_without_trim = explode(",",$source);
		$checked_array_without_trim = explode(",",$checked);
		
		$source_array = array_map('trim', $source_array_without_trim);
		$checked_array = array_map('trim', $checked_array_without_trim);
		$i=0;
		echo "<table border='0' style='border:2px ridge whitesmoke;' width='100%'><tr>";
		foreach($source_array as $v)
		{
			$i=$i+1;
			if(is_array($checked_array))
				if(in_array($v,$checked_array))
					echo "<td><input checked  type='checkbox' name='".$name."[]' value='$v'>$v</td>";
				else
					echo "<td><input type='checkbox' name='".$name."[]' value='$v'>$v</td>";
			else
				echo "<td><input type='checkbox' name='".$name."[]' value='$v'>$v</td>";
			if($i%$col==0)
				echo "</tr><tr>";
		}
		echo "</tr></table>";
	}
	//makecombo
	public function makecombo($source, $selected, $name, $default='', $defaultvalue='',$flag=false)
	{
		$str = '';
		if($flag)
			$str = "validate[required]";
		echo "<select name='$name' id='$name' class='$str form-control'>";
		if($default!='')
			echo "<option value='$defaultvalue'>$default</option>";
		$source_array = array_map('trim', $source);
		foreach($source_array as $k=>$v)
		{
			if($v==$selected)
				echo "<option selected value='$v'>$v</option>";
			else
				echo "<option value='$v'>$v</option>";
		}
		echo "</select>";
	}
	//makecombo_temp
	public function makecombo_temp($source, $selected, $name)
	{
		echo "<select name='$name' id='$name' class='form-control'>";
		$source_array = array_map('trim', $source);
		foreach($source_array as $v)
		{
			if($v==$selected)
				echo "<option selected value='$v'>$v</option>";
			else
				echo "<option value='$v'>$v</option>";
		}
		echo "</select>";
	}
	//getValue
	public function getValue($qry)
	{
		$q = mysqli_query($this->conn,$qry);
		if($q && mysqli_num_rows($q))
			return  mysqli_fetch_row($q);
		else	
			return array(null);
	}
	//getValue
	public function getSingleValue($qry)
	{
		$q = mysqli_query($this->conn,$qry);
		if(mysqli_num_rows($q)==1)
		{
			$r = mysqli_fetch_array($q);
			return $r[0];	
		}else
			return null;
	}
	//getSettingValue
	public function getSettingValue($db_column)
	{
		$q = mysqli_query($this->conn,"select $db_column from tblsettings");
		if($q && mysqli_num_rows($q))
			return  mysqli_fetch_row($q);
		else	
			return '';
	}
	//showData
	public function showData($title, $value)
	{
		if($value)
		if(trim($value)!='')
		{
			/*echo "<div class='box'>";
			echo "<h3>$title</h3>";
			echo "<p>$value</p></div>";*/
			?>
            
            <div style="border-bottom:1px solid;padding-top:5px;">
                <h1><?=$title?></h1>
                <p>
                    <?=$value?>
                </p>
            </div>
            <?php
		}
	}
	//readval
	public function readval($var)
	{
		if($var == null)
			return '';
		else
			return $var;
	}	
	//curPageURL()
	public function curPageURL() {
		$pageURL = 'http';
		if (isset($_SERVER["HTTPS"]) && $_SERVER["HTTPS"] == "on") {$pageURL .= "s";}
		$pageURL .= "://";
		if ($_SERVER["SERVER_PORT"] != "80") {
			$pageURL .= $_SERVER["SERVER_NAME"].$_SERVER["REQUEST_URI"];
			//$pageURL .= $_SERVER["SERVER_NAME"].":".$_SERVER["SERVER_PORT"].$_SERVER["REQUEST_URI"];
		} else {
			$pageURL .= $_SERVER["SERVER_NAME"].$_SERVER["REQUEST_URI"];
		}
		return strtolower($pageURL);
	}
	//checked
	function checked($val)
	{
		if($val=='Y' || $val==true)
			return 'checked';
	}
	//isStudent
	public function isStudent()
	{
		if(!isset($_SESSION['studid']))
			echo "<script> window.location.href='login.php'; </script>";
	}
	//isAdmin()
	public function isAdmin()
	{
		$filename = site_url."error";
		if(!isset($_SESSION['isadmin']))
			echo "<script> window.location.href='$filename';</script>";
	}
	//removeAllExamSessionCookies
	public function removeAllExamSessionCookies()
	{
		if (isset($_SERVER['HTTP_COOKIE']))
		{
			foreach($_COOKIE as $name=>$cookie)
			{
				if(strtolower(substr($name,0,1))=="q" || strtolower(substr($name,0,8))=="selected" || strtolower(substr($name,0,4))=="view")
				{
					setcookie($name, '', time()-3600);
					setcookie($name, '', time()-3600, '/');
				}
			}
		}
		if(isset($_SESSION['examid']))
			unset($_SESSION['examid']); 	
		if(isset($_SESSION['duration']))
			unset($_SESSION['duration']); 
		if(isset($_SESSION['noofque']))
			unset($_SESSION['noofque']);
		if(isset($_SESSION['subject']))
			unset($_SESSION['subject']); 
	}
	//insert
	public function sql_array_insert($table_name, $data, $flag=false)
	{
		$column = '';
		$values = '';
		foreach($data as $k=>$v)
		{
			$column = $column."`$k`,";
			$values = $values."'".trim($v)."',";
		}
		if($flag){
			$column = $column."`insertedon`,`insertedby`";
			$values = $values."NOW(),'".$_SESSION['id']."'";	
		}
		else{
			$column = substr($column, 0, -1);  
			$values = substr($values, 0, -1); 
		}
		$values=str_ireplace("'now()'","now()",$values);
		$values=str_ireplace("'true'","true",$values);
		$values=str_ireplace("'false'","false",$values);
		$qry = "insert into $table_name($column) values($values)";
		//echo "<br />$qry<br />";
		if(mysqli_query($this->conn,$qry)==1)
		{
			$this->system_log($table_name, 'Inserted', $qry);
			return true;
		}
		else
		{
			echo mysqli_error($this->conn);
			return false;
		}
	}
	//update
	public function sql_array_update($table_name, $data, $where, $flag=false)
	{
		$column_values = '';
		foreach($data as $k=>$v)
		{
			$column_values = $column_values."`$k`='".trim($v)."',";
		}
		if($flag){
			$column_values = $column_values."`updatedon`=NOW(),`updatedby`='".$_SESSION['id']."' ";
		}
		else{
			$column_values = substr($column_values, 0, -1);   
		}
		$column_values=str_ireplace("'now()'","now()",$column_values);
		$column_values=str_ireplace("'true'","true",$column_values);
		$column_values=str_ireplace("'false'","false",$column_values);
		$qry = "update $table_name set $column_values where $where";
		//echo $qry;
		if(mysqli_query($this->conn,$qry)==1)
		{
			$this->system_log($table_name, 'Updated', $qry);
			return true;
		}
		else
		{
			echo mysqli_error($this->con);
			return false;
		}
	}
	//delete
	public function sql_array_delete($table_name, $where)
	{
		$column_values = "`isdeleted`=true, `deletedon`=NOW(),`deletedby`='".$_SESSION['id']."' ";
		$column_values=str_replace("'now()'","now()",$column_values);
		$qry = "update $table_name set $column_values where $where";
		//echo $qry;
		if(mysqli_query($this->conn,$qry)==1)
		{
			$this->system_log($table_name, 'Deleted', $qry);
			return true;
		}
		else
		{
			echo mysqli_error($this->con);
			return false;
		}
	}
	public function createpanel($title,$data,$row,$col)
	{
		?>
        <div class="<?=$row?>">
        <div class="<?=$col?>">
		 <div class='panel panel-primary'>
            <div class='panel-heading' align="center">
              <h3 class='panel-title'><?=$title?></h3>
            </div>
            <div class='panel-body'>
			<?=$data?>
            </div>
          </div>
          </div>
          </div>
          <?php
	}
	//sql_array_mydelete
	public function sql_array_mydelete($table_name, $where)
	{
		$column_values = "`isdeleted`=true, `deletedon`=NOW(),`deletedby`='".$_SESSION['studid']."' ";
		$column_values=str_replace("'now()'","now()",$column_values);
		$qry = "update $table_name set $column_values where $where";
		//echo $qry;
		if(mysqli_query($this->conn,$qry)==1)
		{
			$this->system_log($table_name, 'Deleted', $qry);
			return true;
		}
		else
		{
			echo mysqli_error();
			return false;
		}
	}
	//system_log
	public function system_log($table, $tag, $query)
	{
		$id = -1;
		if(isset($_SESSION['id']))
			$id = $_SESSION['id'];
		$qry = "insert into tbllog(byid,ondatetime,tag,table_name,query) values('".$id."',NOW(),'$tag','$table','".mysqli_real_escape_string($this->conn,$query)."')";
		
		mysqli_query($this->conn,$qry);
	}
	//expand
	function expand($content, $count)
	{
		$pos = stripos($content, '%#');
		if($pos===false || $count==6)
			echo $content;
		else
		{
			$courseid = substr($content, $pos+2, stripos($content, '#%')-($pos+2));
			$new_content = $this->getValue("select description from tblcourse where courseid='$courseid'")[0];
			$content = str_replace ("%#$courseid#%",$new_content,$content);
			$this->expand($content, $count++);
		}
	}
	//formatSizeUnits
	function formatSizeUnits($bytes)
    {
        if ($bytes >= 1073741824)
        {
            $bytes = number_format($bytes / 1073741824, 2) . ' GB';
        }
        elseif ($bytes >= 1048576)
        {
            $bytes = number_format($bytes / 1048576, 2) . ' MB';
        }
        elseif ($bytes >= 1024)
        {
            $bytes = number_format($bytes / 1024, 2) . ' KB';
        }
        elseif ($bytes > 1)
        {
            $bytes = $bytes . ' bytes';
        }
        elseif ($bytes == 1)
        {
            $bytes = $bytes . ' byte';
        }
        else
        {
            $bytes = '0 bytes';
        }

        return $bytes;
	}
	//main_heading
	public function main_heading($title, $details)
	{
		echo '<div class="drop-shadow curved-hz-2 text-center">';
		echo '<h1>'.$title.'</h1>';
		echo '<h3>'.$details.'</h3>';
		echo '</div>';
	}
	//main_heading_with_image
	public function main_heading_with_image($title, $details, $img)
	{
		echo '<div class="page_header">';
		echo '<div class="row">';
		echo '<div class="col-md-2">';
		echo '<img width="100%" src="'.$img.'" alt="'.$title.'" title="'.$title.'">';
		echo '</div>';
		echo '<div class="col-md-10">';
		echo '<h1>'.$title.'</h1>';
		echo '<h4>'.$details.'</h4>';
		echo '</div>';
		echo '</div>';
		echo '</div>';
	}
	//cities_with_link
	public function cities_with_link($url, $title)
	{
		$cities = explode(',',org_city);
		echo "<ul>";
		foreach($cities as $city)
		{
			echo "<li><a href='$url' title='$title $city'>$title $city</a> </li>";			
		}
		echo "</ul>";
	}
	//comma_to_space
	function comma_to_space($string)
	{
		$arr = explode(',',$string);
		$result='';
		foreach($arr as $v)
		{
			$node = str_replace(' ','-',trim($v));
			$result = $result.trim($node)." ";
		}
		return $result;
	}
	//unique array
	public function unique_array_mysql($query, $column, $key_column=null)
	{
		$q = mysqli_query($this->conn, $query);
		$string = null;
		$string_key=null;
		while($r=mysqli_fetch_assoc($q)){
			$string = $string .', '. $r[$column];
			if($key_column!=null)
				$string_key = $string_key .', '. $r[$key_column];
		}
		$temp_arr = explode(',',$string);
		if($key_column!=null)
			$temp_key_arr = explode(',',$string_key);
		$new_arr = array();
		$i=0;
		foreach($temp_arr as $k=>$v){
			if(trim($v)!='')
				if($key_column!=null)
					$new_arr[$temp_key_arr[$i++]]=trim($v);
				else
					$new_arr[]=trim($v);
		}
		$arr = array_unique($new_arr);
		return $arr;
	}
	//unique array
	public function array_mysql($query, $val_column, $key_column=null)
	{
		$arr = array();
		$q = mysqli_query($this->conn, $query);
		while($r=mysqli_fetch_assoc($q)){
			$arr[$r[$key_column]] = $r[$val_column];
		}
		return $arr;
	}
	//unique array string
	public function unique_array_string($string)
	{
		$temp_arr = explode(',',$string);
		$new_arr = array();
		$i=0;
		foreach($temp_arr as $k=>$v){
			if(trim($v)!='')
				$new_arr[]=trim($v);
		}
		$arr = array_unique($new_arr);
		return $arr;
	}
	//combo_items
	public function combo_items($array, $selected=array(), $key=false)
	{
		if($key){
			foreach($array as $k=>$v){
				if(in_array($k, $selected))
					echo "<option selected value='$k'>$v</option>";
				else
					echo "<option value='$k'>$v</option>";
			}
		}else{
			foreach($array as $item){
				if(in_array($item, $selected))
					echo "<option selected value='$item'>$item</option>";
				else
					echo "<option value='$item'>$item</option>";
			}
		}
	}
	//generate_button
	function generate_button($string)
	{
		if(is_array($string))
			$temp_arr = $string;
		else{
			$temp_arr = explode(',',$string);
			for($i=0;$i<count($temp_arr);$i++){
				$temp_arr[$i]=trim($temp_arr[$i]);
			}
		}
		$arr = array_unique($temp_arr);
		echo '<li><a href="#all" class="selected" data-filter-value="">All</a></li>';
		foreach($arr as $v){
			$str=trim($v);
			if($v!='')
			echo '<li><a href="#'.str_replace(' ','-',$str).'" data-filter-value=".'.str_replace(' ','-',$str).'">'.$str.'</a></li>';
		}
	}
	//project_tag
	function project_tag($string,$project_name, $link)
	{
		$flag=false;
		$temp_arr = explode(',',$string);
		for($i=0;$i<count($temp_arr);$i++){
			$temp_arr[$i]=trim($temp_arr[$i]);
		}
		$arr = array_unique($temp_arr);
		
		foreach($arr as $v){
			$str=trim($v);
			if($str!=''){
				if($flag)
					echo ', ';
				$flag=true;
				echo '<a href="'.$link.'project/'.$this->urlfriendlyencode($v).'/'.$this->urlfriendlyencode($project_name).'" title="'.$project_name.' '.$v.'">'.$v.'</a>';
			}
		}
	}
	//showDataProject
	public function showDataProject($string,$project_name, $link, $title)
	{
		echo "<div class='box'>";
		echo "<h3>$title</h3>";
		echo "<p>";
		$this->project_tag($string, $project_name, $link);
		echo "</p></div>";
	}
	//sitemap_url
	public function sitemap_url($site_url, $url, $priority)
	{
		echo"<url>";
		echo "<loc>".$site_url.$this->urlfriendlyencode($url)."</loc>";
		echo "<changefreq>weekly</changefreq>";
		echo "<priority>$priority</priority>";
		echo "</url>";
	}
	//home_page_links
	public function home_page_links($title, $tablename, $column, $orderby, $image='myuploads/tsi.png')
	{

		echo '<div class="col-sm-6 col-md-6">';
		echo '<div class="thumbnail">';
		echo "<img src='$image' alt='$title' title='$title'>";
		echo '<div class="caption">';
		echo "<h3>$title</h3>";
		echo '<ul>';
		$q = $this->runquery("select distinct $column from $tablename order by $orderby");
		while($r = mysqli_fetch_assoc($q)){
			extract($r);
			echo "<li><a href='#'>".$r[$column]."</a></li>";
		}
		echo '</ul>';
		echo '</div>';
		echo '</div>';
		echo '</div>';
	}
	//currentdatetime()
	function mysql_now()
	{
		$r = $this->getValue("select NOW()");
		if(isset($r[0]))
			return $r[0];
	}
	//nicetime
	function nicetime($date)
	{
		if(empty($date)) {
			return "No date provided";
		}
	 
		$periods         = array("second", "minute", "hour", "day", "week", "month", "year", "decade");
		$lengths         = array("60","60","24","7","4.35","12","10");
	 
		$now             = strtotime($this->mysql_now());//time();
		$unix_date         = strtotime($date);
		
		// check validity of date
		if(empty($unix_date)) {    
			return "Bad date";
		}
	 
		// is it future date or past date
		if($now > $unix_date) {    
			$difference     = $now - $unix_date;
			$tense         = "ago";
	 
		} else {
			$difference     = $unix_date - $now;
			$tense         = "from now";
		}
	 
		for($j = 0; $difference >= $lengths[$j] && $j < count($lengths)-1; $j++) {
			$difference /= $lengths[$j];
		}
	 
		$difference = round($difference);
	 
		if($difference != 1) {
			$periods[$j].= "s";
		}
	 
		return "$difference $periods[$j] {$tense}";
	}
	//showMessage
	public function showMessage($title, $content, $mode='info')
	{
		?>
     <div class="alert alert-<?=$mode?> alert-dismissible" role="alert">
      	<button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
      <strong><?=$title?></strong> <?=$content?>
    </div>
        <?php
	}
	//isCkecked
	function isChecked($val)
	{
		if($val==true)
			echo 'checked';	
	}
	//box
	function box($title, $info)
	{
		?>
        <div style="border-bottom:1px solid;padding-top:5px;">
        	<h4><?=$title?></h4>
            <p>
            	<?=$info?>
            </p>
        </div>
        <?php	
	}
	//getimage
	function getimage($id, $tag, $size=200, $new_root=null)
	{
		$img_size = null;
		if($size<60)
			$img_size='50_';
		else if($size<120)
			$img_size='100_';
		else if($size<230)
			$img_size='200_';
		else if($size<400)
			$img_size='300_';
		else
			$img_size='_';
		$root = null;
		if(is_dir('uploaded_images'))
			$root = ".";
		else if(is_dir('../uploaded_images'))
			$root = "..";
		else if(is_dir('../../uploaded_images'))
			$root = "../..";
		if($root!=null)
		{
			$path = "$root/uploaded_images/$tag/$id/$img_size*";
			
			//echo "<br />path => $path";
			$images = glob($path);
			if(is_array($images) && count($images)>0)
				if($new_root!=null)
					return $new_root.substr($images[0],strlen($root));
				else
					return $images[0];
			else
				if($new_root!=null)
					return $new_root."/uploaded_images/no-image/$img_size.jpg";
				else
					return $root."/uploaded_images/no-image/$img_size.jpg";
		}
	}
	//active
	function active($page, $cur_page)
	{
		if($page==$cur_page)
			return 'active';
		else
			return null;
	}
	//chart
	public function chart($chart_type, $json_data, $width, $height, $caption, $renderAt,$base_url='')
	{
		if(isset($_GET['chart_type']))
			$chart_type = $_GET['chart_type'];
		$array_chart_type = array('Column2D'=>'Column2D',
								'Column3D'=>'Column3D',
								'Line'=>'Line',
								'Pie3D'=>'Pie3D',
								'Pie2D'=>'Pie2D',
								'Bar2D'=>'Bar2D',
								'Area2D'=>'Area2D',
								'Doughnut2D'=>'Doughnut2D',
								'Doughnut3D'=>'Doughnut3D');
		foreach($array_chart_type as $k=>$v)
		{
			if(strtolower($chart_type)==strtolower($v))
				echo "<a class='btn btn-danger btn-sm' href='".$base_url."chart_type=$v'> $k </a>";
			else
				echo "<a class='btn btn-default btn-sm' href='".$base_url."chart_type=$v'> $k </a>";
		}		
		?>
        <a class='pull-right btn btn-warning btn-sm' onclick="print_chart()"><span class="glyphicon glyphicon-print"></span> Print</a>
       <a class='pull-right btn btn-warning btn-sm' onclick="export_chart()"><span class="glyphicon glyphicon-save"></span> Export</a>
        
        <script type="text/javascript">
		  FusionCharts.ready(function(){
			var revenueChart = new FusionCharts({
				"id": "myChartId",
				"type": "<?=$chart_type?>",
				"renderAt": "<?=$renderAt?>",
				"width": "<?=$width?>",
				"height": "<?=$height?>",
				"dataFormat": "json",
				"dataSource":  {
				  "chart": {
				"caption": "<?=$caption?>",
				"palette": "2",
				"animation": "1",
				"formatnumberscale": "1",
				"decimals": "0",
				"numberprefix": "",
				"pieslicedepth": "15",
				"startingangle": "125",
				"showBorder": "0"
			},
				 "data": [
				 <?php
				 $i=0;
				 foreach($json_data as $k=>$v)
				 {
					 ?>
					 {
					"label": "<?=$k?>",
					"value": "<?=$v?>"
					 }
					 <?php
					 $i++;
					 if($i<count($json_data))
					 	echo ",";
				 }
				 ?>
				
			]
			  }
		
		  });
		revenueChart.render();
		})
		</script>
       <script>
		function print_chart()
		{
			var chartReference = FusionCharts("myChartId" ); 
			if(chartReference)
			{
				chartReference.print()
			}else
				alert("Chart Not Found");
		}
		function export_chart()
		{
			var chartReference = FusionCharts("myChartId" ); 
			if(chartReference)
			{
				chartReference.exportChart( { exportAtClient: '1',  exportFormat: 'PDF' } );

			}else
				alert("Chart Not Found");
		}
		</script>
        <?php
	}
}
