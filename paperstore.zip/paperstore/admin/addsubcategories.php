


<?php
include("head.php");
include("config.php");
include("mylib2.php");
include("leftcall.php");

error_reporting(null);
$m=new mylib();

if(isset($_POST["btnaddsub"]))
{
	extract($_POST);
	
	  $a=$_POST['cmb'];
	
	  $query =$m->runquery("SELECT id FROM categories where cname='$a'");
	 
	  $result=mysql_fetch_array($query);
	  $emp_name=$result['id'];
	  echo $emp_name;
	  $qr=$m->runquery("insert into subcategory(sname,id) values('$txtsub','$emp_name')");
	  
	  echo "<script>alert('Subcategory Inserted Successfully');</script>";
	  }
	  
	
	

?>
 <div align="center">
    <div class='panel panel-primary' class="col-md-3 pull-center">
            <div class='panel-heading'>
              <h3 class='panel-title'>Add Subcategories</h3>
            </div>
 <div class='panel-body'>
	  <form method="post">
	  <table class="table-condensed" align="center">
	   
	  <tr>
	  <td>
	  Select Category: 
	  </td>
	  <td>
<select name="cmb" class="form-control" >
<?php
$qry=mysql_query("select * from categories");
while($r=mysql_fetch_array($qry))
{
	
	
	?>
    <option value="<?=$r["cname"]?>"><?=$r["cname"]?></option>
    <?php
}
?>
</select>
</td>
</tr>
 <tr>
	  <td>
	  Add SubCategories:
	  </td>
	 
  
      <td>
	  <input type="text" name="txtsub" class="form-control" />
	  </td>
 </tr>
	  <tr>
	  <td align="center">
	  <input type="submit" name="btnaddsub" class="btn btn-warning" />
	  </td>
	  </tr>
	  </table>
	  </form>
	
</div>
</div>
</div>