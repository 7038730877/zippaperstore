
var XHRobj=false;
if(window.XMLHttpRequest)
{
	XHRobj=new XMLHttpRequest();
	
}
else if(window.ActiveXObject)
{
	XHRobj=new ActiveXObject("Microsoft.XMLHTTP");
	
}
	
function filldrop()
{
	if(XHRobj)
	{
		
			var path="upload.php.php?id="+document.getElementById("cmb").value;
		
			XHRobj.open("GET",path);
			
			XHRobj.onreadystatechange=function()
			{
			
				if(XHRobj.readyState==4 && XHRobj.status==200)
				{
				
					document.getElementById("d1").innerHTML=XHRobj.responseText;
				}
			}
			XHRobj.send(null);
	}
}

function chkans(opt,ans)
{
	
	if(XHRobj)
	{
	
		var path="data.php?chk="+opt+"&ans="+ans;	
	
		XHRobj.open("GET",path);
		XHRobj.onreadystatechange=function()
		{
			
			if(XHRobj.readyState==4 && XHRobj.status==200)
			{
				
			document.getElementById("s1").innerHTML=XHRobj.responseText;
			}
		}
		XHRobj.send(null);
	}
}
	
	
