<?php include("head.php"); ?>
<?php include("leftcall.php"); ?>
<?php

include("config.php");
include("mylib.php");
error_reporting(null);
$m=new mylib();

if(isset($_POST["btnadd"]))
{
	extract($_POST);
	$qry=$m->runquery("insert into categories (cname) values('$txtcategories')");
	
	
}
?>

<?php $my_var = <<<EOD

	<form method="post" >  
<table align="center">
<tr>
<td>
Add Categories:
</td>
<td>
<input type="text" class="form-control" placeholder="Add Categories" name="txtcategories" />
</td>

</tr>
<tr>
<td>
<input type="submit" name="btnadd" class="btn btn-warning" />
</td>
</tr>
</table>
</form>
EOD;

$m->createpanel("Add Category","$my_var","","col-md-6");
?>
