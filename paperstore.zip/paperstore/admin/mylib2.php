<?php
 class mylib
{
public function runquery($qry)
	{
      $q=mysql_query($qry);
	  return $q;
	}
	public  function fillcombo($qry,$item,$combo1)
	{
		echo "<select name='$combo1'>";
		
		while($r=mysql_fetch_array($qry))
		{
			echo "<option value='$r[$item]'>$r[$item]</option>";
		}
		echo "</select>";
		
	}
function runQuery1($query) {
		$result = mysql_query($query);
		while($row=mysql_fetch_assoc($result)) {
			$resultset[] = $row;
		}		
		if(!empty($resultset))
			return $resultset;
	}
}
?>