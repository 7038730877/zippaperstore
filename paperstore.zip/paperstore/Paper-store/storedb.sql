-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Nov 06, 2015 at 09:10 PM
-- Server version: 5.5.39
-- PHP Version: 5.4.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `storedb`
--

-- --------------------------------------------------------

--
-- Table structure for table `adminlogin`
--

CREATE TABLE IF NOT EXISTS `adminlogin` (
`adminid` int(11) NOT NULL,
  `adminemail` varchar(50) NOT NULL,
  `adminpass` varchar(50) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `adminlogin`
--

INSERT INTO `adminlogin` (`adminid`, `adminemail`, `adminpass`) VALUES
(1, 'neha@gmail.com', '1234'),
(2, '', ''),
(3, 'p@gmail.com', '1234');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE IF NOT EXISTS `categories` (
`id` int(11) NOT NULL,
  `cname` varchar(50) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `cname`) VALUES
(1, 'Writting Supliers'),
(2, 'Office Stationary'),
(3, 'Greetings'),
(4, 'Papers');

-- --------------------------------------------------------

--
-- Table structure for table `merge`
--

CREATE TABLE IF NOT EXISTS `merge` (
`mid` int(11) NOT NULL,
  `id` int(11) NOT NULL,
  `sid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `subcategory`
--

CREATE TABLE IF NOT EXISTS `subcategory` (
`sid` int(11) NOT NULL,
  `sname` varchar(50) NOT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=54 ;

--
-- Dumping data for table `subcategory`
--

INSERT INTO `subcategory` (`sid`, `sname`, `id`) VALUES
(16, 'pen', 1),
(17, 'birthday greeting', 3),
(34, 'Correction Media', 1),
(35, 'Erasers', 1),
(36, 'HighLighters', 1),
(37, 'Pencils', 1),
(38, 'Desk accesseries', 2),
(39, 'carbon paper', 4),
(40, 'composition books', 4),
(42, 'notes book', 4),
(43, 'computer paper', 4),
(44, 'sticky paper', 4),
(45, 'paper envelops', 4),
(46, 'friendship greeting', 3),
(47, 'teachersDay greeting', 3),
(48, 'Crayons & Pastels', 1),
(49, 'Fathers day Greeting', 3),
(50, 'Mothers Day Greeting', 3),
(51, 'Refile Leads', 1),
(52, 'Office Files-Folders', 2),
(53, 'Printer-Plotters Accessories', 2);

-- --------------------------------------------------------

--
-- Table structure for table `tbladdtocart`
--

CREATE TABLE IF NOT EXISTS `tbladdtocart` (
`aid` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `pid` int(11) NOT NULL,
  `pqty1` varchar(50) NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=23 ;

--
-- Dumping data for table `tbladdtocart`
--

INSERT INTO `tbladdtocart` (`aid`, `email`, `pid`, `pqty1`, `price`) VALUES
(1, 'n@gmail.com', 34, '1', 0),
(3, 'r@gmail.com', 27, '', 0),
(4, 'r@gmail.com', 34, '', 0),
(5, 'r@gmail.com', 26, '', 0),
(7, 'n@gmail.com', 27, '2', 0),
(11, 'n@gmail.com', 36, '1', 0),
(14, 'p@gmail.com', 36, '3', 0),
(16, '', 0, '', 316),
(17, '', 0, '', 400),
(18, '', 0, '', 100),
(19, '', 0, '', 316),
(20, '', 0, '', 400),
(21, '', 34, '', 0),
(22, 'r@gmail.com', 36, '2', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tblbuy`
--

CREATE TABLE IF NOT EXISTS `tblbuy` (
`bid` int(11) NOT NULL,
  `fname` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `address` varchar(50) NOT NULL,
  `city` varchar(50) NOT NULL,
  `state` varchar(50) NOT NULL,
  `contry` varchar(50) NOT NULL,
  `pcode` varchar(50) NOT NULL,
  `mobile` varchar(50) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `tblbuy`
--

INSERT INTO `tblbuy` (`bid`, `fname`, `email`, `address`, `city`, `state`, `contry`, `pcode`, `mobile`) VALUES
(2, 'neha', 'n@gmail.com', 'bxhx', 'Nashik', 'Maharashtra', 'India', '422303', '78945612'),
(3, 'ri', 'r@gmail.com', 'm x', 'ms sjdx', 'msndjsd', 'smn xcjsxc', '1233', '3456'),
(4, 'prajakta', 'p@gmail.com', 'nashik', 'Nashik', 'Maharashtra', 'India', '12345', '345678'),
(5, 'Rohini', 'r@gmail.com', 'Niphad', 'Niphad', 'Niphad', 'Maharashtra', '422134', '1234567894');

-- --------------------------------------------------------

--
-- Table structure for table `tblregister`
--

CREATE TABLE IF NOT EXISTS `tblregister` (
`id` int(11) NOT NULL,
  `fname` varchar(50) NOT NULL,
  `mnumber` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `repassword` varchar(50) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `tblregister`
--

INSERT INTO `tblregister` (`id`, `fname`, `mnumber`, `email`, `password`, `repassword`) VALUES
(1, 'neha', '123456', 'n@gmail.com', 'Neha@1234', 'Neha@1234'),
(2, 'prajakta', '234567891', 'p@gmail.com', 'Praju@123', 'Praju@123'),
(3, 'rohini', 'r@gmail.com', 'r@gmail.com', 'Rohini@123', 'Rohini@123'),
(4, 'prajakta', '1234', 'p@gmail.com', 'Praju@123', 'Praju@123');

-- --------------------------------------------------------

--
-- Table structure for table `tbltotal`
--

CREATE TABLE IF NOT EXISTS `tbltotal` (
`tid` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `total` varchar(50) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `tbltotal`
--

INSERT INTO `tbltotal` (`tid`, `email`, `total`) VALUES
(7, 'n@gmail.com', '100'),
(8, 'n@gmail.com', '316'),
(9, 'n@gmail.com', '400'),
(10, 'p@gmail.com', '1200'),
(11, 'r@gmail.com', '0'),
(12, 'r@gmail.com', '0'),
(13, 'r@gmail.com', '800'),
(14, 'r@gmail.com', '0'),
(15, 'r@gmail.com', '0'),
(16, 'r@gmail.com', '800');

-- --------------------------------------------------------

--
-- Table structure for table `tblupload1`
--

CREATE TABLE IF NOT EXISTS `tblupload1` (
`id` int(11) NOT NULL,
  `title` varchar(50) NOT NULL,
  `path` varchar(70) NOT NULL,
  `pdescription` text NOT NULL,
  `pprice` varchar(50) NOT NULL,
  `qty` varchar(50) NOT NULL,
  `sid` int(11) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=92 ;

--
-- Dumping data for table `tblupload1`
--

INSERT INTO `tblupload1` (`id`, `title`, `path`, `pdescription`, `pprice`, `qty`, `sid`) VALUES
(27, 'Puro 5 In 1 Multipurpose Pen', 'upload/writting supliers/pen/41vqEzt1JvL.jpg', 'Red Laser LightLED LightBlack Ball PenRetractable pointer which makes presentations convenientMagnet', ' 158.00 ', '40', 16),
(32, 'Puro 5 In 1 Multipurpose Pen', 'upload/writting supliers/pen/c.jpg', '<p>pkhsdihds</p>\r\n', '100', '', 16),
(33, 'Business Birthday Paper Card (Cake)', 'upload/greetings/birthday greeting/z.jpg', '<ul>\r\n	<li>Qubie Creative Gift Card</li>\r\n	<li>Display Size:11.8X5.9 Inches (30X15cm)</li>\r\n	<li>Including envelope and Opp bag</li>\r\n	<li>You can add your own words as you needed</li>\r\n	<li>Fantastic birthday card for your family, colleague and friends etc whoever you love</li>\r\n</ul>\r\n', '700', '', 17),
(34, 'Pilot FriXion Clicker Retractable Erasable Gel Pen', 'upload/writting supliers/pen/y.jpg', '<ul>\r\n	<li>Combines the convenience of a retractable with the incredible FriXion erasable gel ink</li>\r\n	<li>Erase and rewrite repeatedly without damaging documents - Eraser is at the top of the pen, tip is retractable by pressing clip down</li>\r\n	<li>Unique Thermo-Sensitive gel ink formula disappears with erasing friction</li>\r\n	<li>Assorted color pouch containing 7 colors - Black, blue, red, turquoise, purple, green and pink</li>\r\n</ul>\r\n', '100', '', 16),
(35, 'DecoBros Desk Supplies Organizer Caddy', 'upload/Office Stationary/Desk accesseries/da1.jpg', '<ul>\r\n	<li>Mesh Oval Pencil Cup comes with extra organizational features</li>\r\n	<li>5 divided compartments to organize all your writing instruments</li>\r\n	<li>2 additional shallow compartments for holding clips or other small supplies</li>\r\n	<li>Small notched supply drawer pulls out to hold 2.5&quot; x 3&quot; notes</li>\r\n</ul>\r\n', '700', '', 38),
(36, 'bithday greeting', 'upload/Greetings/birthday greeting/images (3).jpg', '<p>birthday greetings for birthday</p>\r\n', '400', '30', 17),
(37, '1 Dozen (12) Christmas Pencil Assortment', 'upload/Writting Supliers/Pencils/2.jpg', '<ul>\r\n	<li>Christmas Holiday Theme Pencils</li>\r\n	<li>12 pencils</li>\r\n	<li>Styles May Vary</li>\r\n</ul>\r\n', '100', '30', 37),
(38, 'Apsara Absolute Extra Dark Pencils - Pack of 10', 'upload/Writting Supliers/Pencils/3.jpg', '<ul>\r\n	<li>50 % stronger lead that resists breaking while writing and sharpening</li>\r\n	<li>Special wood for easy sharpening</li>\r\n	<li>Extra dark lead for good handwriting</li>\r\n</ul>\r\n', '70', '40', 37),
(39, 'Camlin Klick Pro Mechanical Pencil, 0.5mm', 'upload/Writting Supliers/Pencils/31izHZeLn6L.jpg', '<ul>\r\n	<li>Grip for comfortable writing</li>\r\n	<li>Sturdy metal clip</li>\r\n	<li>Trendy tip</li>\r\n	<li>Built-in-Eraser</li>\r\n	<li>Available in 5 attractive colours</li>\r\n	<li>Colour of the product delivered is subjected to availability</li>\r\n</ul>\r\n', '20', '50', 37),
(42, 'BIC Brite Liner Highlighters, Chisel Tip, Assorted', 'upload/Writting Supliers/HighLighters/zx_.jpg', '<ul>\r\n	<li>Super bright fluorescent ink</li>\r\n	<li>Chisel tip for broad highlighting or fine underlining</li>\r\n	<li>ACMI approved non-toxic</li>\r\n	<li>Available in assorted ink</li>\r\n	<li>Made in the USA of US &amp; Foreign Parts</li>\r\n</ul>\r\n', '50', '60', 36),
(43, 'iGlider Smart Stand Screen Cleaner Phone Tablet Ho', 'upload/Writting Supliers/HighLighters/yx_.jpg', '<ul>\r\n	<li>3 Gel Stick Highlighters</li>\r\n	<li>Phone/Tablet Holder</li>\r\n	<li>Screen Cleaner</li>\r\n	<li>No Bleed! Bible safe</li>\r\n	<li>Case holds iCliders</li>\r\n</ul>\r\n', '300', '60', 36),
(44, '6pc Multi Colors Colorful Syringe Highlighter Pens', 'upload/Writting Supliers/HighLighters/xc.jpg', '<ul>\r\n	<li>Condition: 100% Brand new</li>\r\n	<li>Material: PVC</li>\r\n	<li>The perfect gift for every member of your nursing staff</li>\r\n	<li>Color: Purple, Green, Orange, Blue, Pink, Yellow</li>\r\n	<li>Package Content: 6 Syringe Highlighters</li>\r\n</ul>\r\n', '192', '70', 36),
(45, 'Eco Highlighter Pencils - Set of 5 Colors - Will N', 'upload/Writting Supliers/HighLighters/vx.jpg', '<ul>\r\n	<li>SUSTAINABLE - responsibly made (wood from managed forests) with a natural finish so they are biodegradable (no plastics, no ink solvents, no volatile organic compounds).</li>\r\n	<li>LONG LASTING - dry highlighters don&#39;t bleed through thin pages, leak or dry out. They sharpen easily and the core will not chip or crumble like other brands. Excellent for home, school and office.</li>\r\n	<li>SIZE DIMENSIONS - the pencils are JUMBO sized (3/8 inch in diameter x 6 7/8 inches in length) and hexagon shape - comfortable to hold and use. To sharpen, use a JUMBO sharpener</li>\r\n	<li>HIGHLIGHTER SET - includes 5 neon colors (pink, orange, yellow, green, blue) and a JUMBO pencil sharpener. Please read Product Description for more details and useful tips.</li>\r\n</ul>\r\n', '150', '70', 36),
(46, 'Eco Highlighter Pencils - Set of 5 Colors - Will N', 'upload/Writting Supliers/Pencils/vx.jpg', '<ul>\r\n	<li>responsibly made (wood from managed forests) with a natural finish so they are biodegradable (no plastics, no ink solvents, no volatile organic compounds).</li>\r\n	<li>LONG LASTING - dry highlighters don&#39;t bleed through thin pages, leak or dry out. They sharpen easily and the core will not chip or crumble like other brands. Excellent for home, school and office.</li>\r\n</ul>\r\n', '150', '50', 37),
(47, 'Paper Mate Pink Pearl Premium Erasers, 3 Pack, Lar', 'upload/Writting Supliers/Erasers/wq.jpg', '<ul>\r\n	<li>This classic premium eraser easily removes pencil marks.</li>\r\n	<li>Soft pliable rubber elastomer compound is easy to maneuver and does not tear paper.</li>\r\n	<li>For everyone from students to serious artists.</li>\r\n	<li>Eraser is self-cleaning and smudge resistant, so your paper stays clean.</li>\r\n	<li>Includes 3 large erasers.</li>\r\n</ul>\r\n', '50', '60', 35),
(48, 'Paper Mate White Pearl Premium Erasers, White, 3 P', 'upload/Writting Supliers/Erasers/ew.jpg', '<ul>\r\n	<li>This classic premium eraser easily removes pencil marks.</li>\r\n	<li>100% latex free compound is easy to maneuver and does not tear paper.</li>\r\n	<li>For everyone from students to serious artists.</li>\r\n	<li>Eraser is self-cleaning and smudge resistant, so your paper stays clean.</li>\r\n</ul>\r\n', '60', '70', 35),
(49, 'Set Of 36-Crayon Shaped Erasers-Assorted Colors. 3', 'upload/Writting Supliers/Erasers/re.jpg', '<ul>\r\n	<li>2.75 INCHES</li>\r\n	<li>REAL CUTE</li>\r\n	<li>LOOK LIKE REAL CRAYONS</li>\r\n	<li>36 IN PACK</li>\r\n	<li>ASSORTED COLORS</li>\r\n</ul>\r\n', '180', '60', 35),
(50, 'Fun Express Mini Eraser Assortment Novelty (500 Pi', 'upload/Writting Supliers/Erasers/ba.jpg', '<ul>\r\n	<li>500 Mini Eraser Assortment</li>\r\n	<li>See images on this listing.</li>\r\n	<li>Fun express toy</li>\r\n</ul>\r\n', '350', '60', 35),
(51, 'Brother Lift Off (Correction) Tape 6 Pack ', 'upload/Writting Supliers/Correction Media/cor.jpg', '<ul>\r\n	<li>Manufacturer: Brother</li>\r\n</ul>\r\n', '40', '70', 34),
(52, 'Faber-castell Oil Pastels Set of 50', 'upload/Writting Supliers/Crayons & Pastels/vd.jpg', '<ul>\r\n	<li>Ideal for colour mixing, etching, tinting &amp; shading, and creating textured designs</li>\r\n	<li>Superior Colour mixing, Rich and bright colours.</li>\r\n	<li>Super smooth and easy to apply.</li>\r\n</ul>\r\n', '200', '50', 48),
(53, 'Lion Brand Yarn 601-680 Bonbons Yarn, Crayons', 'upload/Writting Supliers/Crayons & Pastels/n.jpg', '<ul>\r\n	<li>Indulge in color with Bonbons, our collections of 8 miniature skeins of yarn, perfect for any project requiring multiple colors</li>\r\n	<li>100% Acrylic</li>\r\n</ul>\r\n', '79', '80', 48),
(54, 'Reeves Water Soluble Wax Pastels 12', 'upload/Writting Supliers/Crayons & Pastels/rs.jpg', '<ul>\r\n	<li>Vibrant strong colors</li>\r\n	<li>Smooth and creamy consistency</li>\r\n	<li>Blend easily - ideal for color mixing</li>\r\n	<li>Easy to apply wet or dry</li>\r\n</ul>\r\n', '450', '130', 48),
(55, 'Faber-castell Oil Pastels Set of 50 Easy to Pack a', 'upload/Writting Supliers/Crayons & Pastels/fa.jpg', '<ul>\r\n	<li>Ideal for colour mixing, etching, tinting &amp; shading, and creating textured designs</li>\r\n	<li>Superior Colour mixing, Rich and bright colours, Super smooth and easy to apply.</li>\r\n	<li>Complies with EN-71 (European) &amp; ACMI (American) Quality Standards</li>\r\n	<li>Special colours in set of 48 - 4 Fluoro &amp; 1 Silver to add that special effect &amp; shimmer to painting.</li>\r\n	<li>Easy to pack and carry Colour tool Box</li>\r\n</ul>\r\n', '640', '100', 48),
(56, 'Pentel Super Hi-Polymer Lead Refills, 0.5 mm, 90 P', 'upload/Writting Supliers/Refile Leads/fil.jpg', '<ul>\r\n	<li>Triple Threat: #1 selling lead, Industry Standard, Stronger than competitors</li>\r\n	<li>0.5 mm fine lines</li>\r\n	<li>Resists breaking</li>\r\n	<li>Equivalent to a #2 pencil and guaranteed to scan</li>\r\n	<li>90 pieces of lead - 3 Tubes of 30 pieces</li>\r\n</ul>\r\n', '20', '50', 51),
(57, 'Pentel Super Hi-Polymer Lead Refill, 0.7mm Medium,', 'upload/Writting Supliers/Refile Leads/il.jpg', '<ul>\r\n	<li>Resists breaking and never needs sharpening</li>\r\n	<li>0.7mm, medium lines</li>\r\n	<li>2B is a soft lead that produces a dark line density</li>\r\n	<li>Easy to read and smooth writing feel</li>\r\n	<li>Fits all 0.7mm mechanical pencils</li>\r\n	<li>144 pieces of lead - 12 tubes of 12 pieces of lead</li>\r\n</ul>\r\n', '250', '40', 51),
(58, 'Greeting Pen "Teachers Shape the Future" #1 Teache', 'upload/Writting Supliers/pen/rp.jpg', '<ul>\r\n	<li>Set includes 6 pens; each pen is a &quot;Teachers Shape the Future&quot; #1 Teacher pen with 4 messages of appreciation that rotate with every click of the pen:</li>\r\n	<li>Message 1: Thank You For Teaching Me</li>\r\n	<li>Message 2: What I Need To Know in Ways I Understand</li>\r\n	<li>Message 3: and for Helping Me Learn Right From Wrong</li>\r\n	<li>Message 4: with Kindness and Patience All Day Long</li>\r\n</ul>\r\n', '140', '76', 16),
(59, 'Jumbo Funny Thank You Card', 'upload/Greetings/teachersDay greeting/te.jpg', '<ul>\r\n	<li>Card&#39;s inside greeting: You&#39;re the best!</li>\r\n	<li>Big Thank You Wishes Requires a Big 8.5&#39;&#39; by 11&#39;&#39;</li>\r\n</ul>\r\n', '120', '39', 47),
(60, 'TEACHER SCHOOL DAYS GREETING CARD FOR THANK YOU TE', 'upload/Greetings/teachersDay greeting/rt.jpg', '<ul>\r\n	<li>BRILLIANT TEACHER SCHOOL DAYS GREETING CARD FOR THANK YOU TEACHER</li>\r\n	<li>By Hallmark</li>\r\n</ul>\r\n', '240', '30', 47),
(61, 'Free Teacher Day ecards', 'upload/Greetings/teachersDay greeting/tea.jpg', '<ul>\r\n	<li>Open network sockets</li>\r\n	<li>Access information about networks</li>\r\n</ul>\r\n', '234', '45', 47),
(62, 'Rose Best Papa Ever - Gifts', 'upload/Greetings/Fathers day Greeting/pa.jpg', '<p>Fathers day greeting</p>\r\n', '150', '65', 49),
(63, 'Father Daddy Happy Thanks Love Best Greeting Card', 'upload/Greetings/Fathers day Greeting/da.jpg', '<ul>\r\n	<li>Designed and created by QuickieCards</li>\r\n	<li>Shipping is always FREE</li>\r\n</ul>\r\n', '324', '54', 49),
(64, 'Porelon Black Carbon Paper, 8.5 x 11 Inches, 25 Sh', 'upload/Papers/carbon paper/car.jpg', '<ul>\r\n	<li>8 1/2 x 11 inch carbon copy sheets</li>\r\n	<li>High quality and convenient</li>\r\n	<li>25 black sheets</li>\r\n	<li>Ideal for home or office use</li>\r\n	<li>One year (12 months) warranty from date of purchase</li>\r\n</ul>\r\n', '50', '144', 39),
(65, 'Roaring Spring Carbon Paper Tablet, 10 Sheets per ', 'upload/Papers/carbon paper/5L.jpg', '<ul>\r\n	<li>Carbon paper sheets</li>\r\n	<li>10 sheets per pad</li>\r\n	<li>8.5&quot; x 11&quot;</li>\r\n	<li>Sheets tear out</li>\r\n	<li>Backer with each sheet</li>\r\n</ul>\r\n', '146', '23', 39),
(66, '15 Envelope + 1 Sheet Label Seal Sticker ', 'upload/Papers/paper envelops/5v.jpg', '<ul>\r\n	<li>Material: Paper</li>\r\n	<li>Paper Size:7 x 11 inch Envelope Size: 6.7 x4.3 inch</li>\r\n	<li>Quantity: 30 pcs Writting Paper + 15 Envelope + 1 Sheet Label Seal Sticker (various Styles will be sent, each style contains 6 writing paper and 3 envelope)</li>\r\n	<li>Color: as the picture shows(Randomly color sent)</li>\r\n</ul>\r\n', '276', '59', 45),
(67, '100 Pack Maxtek Premium Thick White Paper CD DVD S', 'upload/Papers/paper envelops/10.jpg', '<ul>\r\n	<li>Maxtek Premium Paper Sleeves With 4 Inch Clear Window.</li>\r\n	<li>Material: 100g Heavy Weight Paper, better quality and thicker than regular 80g paper.</li>\r\n	<li>Affordable, easy to use.</li>\r\n	<li>Window covered by transparent film.</li>\r\n	<li>100 pack total.</li>\r\n</ul>\r\n', '160', '50', 45),
(68, 'Flat Resealable Envelopes', 'upload/Papers/paper envelops/15jpg.jpg', '<ul>\r\n	<li>100 A6 / A2 Crystal Clear Flat Resealable Envelopes - 4 3/4&quot; x 6 1/2&quot; or 4.75 x 6.5</li>\r\n	<li>Polypropylene Bags with Lip Tape</li>\r\n	<li>Fits A6 Card without a Paper Envelope or A2 Size Card with Paper Envelope</li>\r\n	<li>Resealable Side Opening</li>\r\n	<li>Ideal for hand crafted cards, crafts, and treats</li>\r\n</ul>\r\n', '243', '56', 45),
(69, 'A2 Euro Flap Envelope 4 3/8 x 5 3/4 - Stardream An', 'upload/Papers/paper envelops/5.jpg', '<ul>\r\n	<li>Finish: Metallic</li>\r\n	<li>Eco Features: Acid Free, Lignin Free</li>\r\n	<li>50 Pack</li>\r\n</ul>\r\n', '354', '65', 45),
(70, 'Composition Books Wide Ruled ', 'upload/Papers/composition books/9.jpg', '<ul>\r\n	<li>5 pack, 80 sheets each, 400 total 7.5&quot; x 9.75&quot;</li>\r\n	<li>Assorted Colors (Blue, Green, Pink, Orange, Red, Black, Teal Lime, Purple)</li>\r\n	<li>Wide Ruled</li>\r\n	<li>Composition Books</li>\r\n	<li>Outside Cover made of Poly</li>\r\n</ul>\r\n', '250', '665', 40),
(73, 'Mead Composition Book', 'upload/Papers/composition books/51.jpg', '<ul>\r\n	<li>Primary Composition book helps kids grades K-2 develop their penmanship; conforms to McDougall-Littell, Zaner Bloser, and D&#39;Nealian handwriting methods</li>\r\n	<li>Kids position their letters using the redline cues, solid and dotted line primary rulings; a narrow line width helps them with pencil control; inside front cover includes manuscript alphabet for reference; no vertical margins mean the entire page is available for writing practice</li>\r\n</ul>\r\n', '70', '76', 40),
(74, 'Multipurpose Paper, 8.5x11-Inch, Pack of 3 ', 'upload/Papers/computer paper/8.jpg', '<ul>\r\n	<li>Convenience Pack Contains 3 Reams of Paper at 500 Sheets Each 1500 Total Sheets</li>\r\n	<li>Buyers Laboratory Certified (BLI)</li>\r\n	<li>Sustainable Forestry Initiative Certified Chain of Custody</li>\r\n	<li>92 Bright White 20 Pound Standard Weight 8.5 x 11 Inches Letter Size Paper</li>\r\n	<li>Packaging may vary</li>\r\n</ul>\r\n', '690', '79', 43),
(75, 'UltraHold Sticky Notes Graph Pad, 4" x 4", 75 Shee', 'upload/Papers/sticky paper/7.jpg', '<ul>\r\n	<li>Sticky notes as graph paper in compact size.</li>\r\n	<li>75 sheets</li>\r\n	<li>graph paper has 4 squares per inch</li>\r\n	<li>4&quot; x 4&quot;</li>\r\n	<li>great for craft projects, math problems, and much more</li>\r\n</ul>\r\n', '312', '65', 44),
(76, 'YOPO Sticky Back Chalkboard Contact Paper for Home', 'upload/Papers/sticky paper/51z.jpg', '<ul>\r\n	<li>Turn any flat smooth surface into a unique chalkboard! Wipes clean easily.</li>\r\n	<li>Easy to apply, easy to remove and easy to keep clean.</li>\r\n	<li>Features an easy-to-peel liner and an adhesive that allows it to be repositioned during installation without leaving a sticky residue. Simply cut to length or shape for a custom application.</li>\r\n</ul>\r\n', '543', '76', 44),
(77, 'Sticky Note Mini Graph Pads - 5 Count ', 'upload/Papers/sticky paper/rew.jpg', '<ul>\r\n	<li>Package includes 5 Pads at 25 Adhesive Sheets per Pad</li>\r\n	<li>Adhesive area is 3&quot; x 1&quot; to provide staying power</li>\r\n	<li>Labeled x-axis, y-axis, and origin</li>\r\n	<li>Grid is 20 x 20 units total (see picture)</li>\r\n	<li>Size is 3&quot; x 3&quot;</li>\r\n</ul>\r\n', '30', '87', 44),
(80, 'HP LaserJet 4200TN Printer ', 'upload/Office Stationary/Printer-Plotters Accessories/hp.jpg', '<ul>\r\n	<li>HP LaserJet 4200TN Printer</li>\r\n</ul>\r\n', '7200', '32', 53),
(81, 'HP Designjet T120 24-in ePrinter', 'upload/Office Stationary/Printer-Plotters Accessories/6.jpg', '<ul>\r\n	<li>HP Designjet T120 Thermal Inkjet 24&quot; ePrinter</li>\r\n</ul>\r\n', '6000', '30', 53),
(82, 'Epson WorkForce 1100 Wide-Format Color Inkjet Prin', 'upload/Office Stationary/Printer-Plotters Accessories/ep.jpg', '<ul>\r\n	<li>Print standard-size documents,index cards,stationery or large spreadsheets with prints up to 13 x 19 inches</li>\r\n	<li>This powerful performer boasts maximum print speeds of 30 ppm black/17 ppm color and laser quality speeds of 13 ppm black/5.5 ppm color</li>\r\n	<li>Protect important documents with instant-dry ink for smudge,fade and water resistant prints,highlighter-friendly too</li>\r\n	<li>You can save up to 50% of your paper supply with manual,two-sided printing</li>\r\n	<li>Dual Black ink cartridges included</li>\r\n	<li>High-capacity black,cyan,magenta and yellow ink cartridges available</li>\r\n	<li>Wide-format prints</li>\r\n</ul>\r\n', '8000', '30', 53),
(83, 'Pendaflex Two-Tone Color File Folders', 'upload/Office Stationary/Office Files-Folders/fp.jpg', '<ul>\r\n	<li>Foolproof filing with lighter interior</li>\r\n	<li>Letter size; 3 tab positions</li>\r\n	<li>Durable 11 pt. covers in assorted colors: blue, yellow, red, bright green, orange</li>\r\n	<li>Paper made from 10% recycled fiber with 10% post-consumer fiber</li>\r\n	<li>100 per box</li>\r\n</ul>\r\n', '340', '46', 52),
(84, 'Smead Campus.org® Poly Subject File Folder, 10 Poc', 'upload/Office Stationary/Office Files-Folders/fl.jpg', '<ul>\r\n	<li>Perfect for organizing class paperwork and school projects</li>\r\n	<li>Ten 5&quot; high pockets securely hold documents</li>\r\n	<li>Assorted colors - teal or royal blue</li>\r\n	<li>Durable poly is tear proof and water resistant</li>\r\n	<li>Acid free, PVC free and archival quality</li>\r\n</ul>\r\n', '270', '54', 52),
(85, 'Blue and Gold Peacock Decorative File Folders (Set', 'upload/Office Stationary/Office Files-Folders/pi.jpg', '<ul>\r\n	<li>Each folder is approximately 8.5 x 11.8 inches</li>\r\n	<li>Features decorative gold accents</li>\r\n	<li>A great way to add interest to boring paperwork!</li>\r\n	<li>Makes a great gif</li>\r\n</ul>\r\n', '600', '54', 52),
(86, 'Five Star Poly Folder, 4-pocket-2 in 1,(', 'upload/Office Stationary/Office Files-Folders/fiv.jpg', '<ul>\r\n	<li>Two folders in one for 4 pockets of organization. 3-hole punched to store in binders. Durable plastic construction lasts all year</li>\r\n	<li>9 1/2&quot; x 11 3/4&quot; x 1/4</li>\r\n	<li>Water-resistant laminated paper.</li>\r\n	<li>Three-hole punched for use with standard three-ring binders.</li>\r\n	<li>Produced with the highest grade materials</li>\r\n</ul>\r\n', '390', '76', 52),
(87, 'DecoBros Mesh Desk Organizer with Double Tray and ', 'upload/Office Stationary/Desk accesseries/des.jpg', '<ul>\r\n	<li>Space-saving mesh wire design</li>\r\n	<li>Two side load letter trays with five 2&quot; compartments.</li>\r\n	<li>File Folder and Letter Organizer</li>\r\n	<li>Desk storage</li>\r\n	<li>USPTO Patent: USD717371</li>\r\n</ul>\r\n', '400', '54', 38),
(88, 'Safco Products 3261BL Onyx Mesh Desktop Corner Org', 'upload/Office Stationary/Desk accesseries/cro.jpg', '<ul>\r\n	<li>Four horizontal sections, two upright sections</li>\r\n	<li>Use as a 90 degree corner desktop organizer</li>\r\n	<li>Unique design allows 2 ways to organize</li>\r\n	<li>Steel mesh construction</li>\r\n	<li>Durable powder coat finish</li>\r\n</ul>\r\n', '544', '43', 38),
(89, 'Deli Smiling Binder Clips ,19mm ,Assorted Colors ,', 'upload/Office Stationary/Desk accesseries/bid.jpg', '<ul>\r\n	<li>A great alternative to small or mini binder clips or jumbo paper clips</li>\r\n	<li>Handles can fold up for handing or can be removed for binding</li>\r\n	<li>Strong heat treated steel grips papers securely</li>\r\n	<li>Comes in 40 in a reusable storage tub</li>\r\n</ul>\r\n', '165', '65', 38),
(90, 'Pentel Presto Metal Tip Fine Point Correction Pen ', 'upload/Writting Supliers/Correction Media/2.jpg', '<ul>\r\n	<li>Multipurpose correction pen has a fine point metal tip and a pocket clip.</li>\r\n	<li>Opaque fluid lays down smoother, offers complete coverage with no show-through or flaking.</li>\r\n	<li>Fine point metal tip for is perfect for small print.</li>\r\n	<li>Pocket clip for on-the-go convenience.</li>\r\n	<li>Ozone-safe formula.</li>\r\n</ul>\r\n', '45', '143', 34),
(91, 'Paper Mate Correction Fluid, 22ml, Ledger Buff ', 'upload/Writting Supliers/Correction Media/3.jpg', '<ul>\r\n	<li>All-purpose correction fluid is formulated to match popular paper colors</li>\r\n	<li>Foam applicator helps apply fluid evenly and smoothly</li>\r\n	<li>Correction fluid offers maximum coverage and fast-drying formula in a spill-resistant bottle</li>\r\n</ul>\r\n', '90', '68', 34);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `adminlogin`
--
ALTER TABLE `adminlogin`
 ADD PRIMARY KEY (`adminid`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `merge`
--
ALTER TABLE `merge`
 ADD PRIMARY KEY (`mid`), ADD KEY `id` (`id`), ADD KEY `sid` (`sid`);

--
-- Indexes for table `subcategory`
--
ALTER TABLE `subcategory`
 ADD PRIMARY KEY (`sid`), ADD KEY `id` (`id`), ADD KEY `id_2` (`id`), ADD KEY `id_3` (`id`), ADD KEY `id_4` (`id`);

--
-- Indexes for table `tbladdtocart`
--
ALTER TABLE `tbladdtocart`
 ADD PRIMARY KEY (`aid`);

--
-- Indexes for table `tblbuy`
--
ALTER TABLE `tblbuy`
 ADD PRIMARY KEY (`bid`);

--
-- Indexes for table `tblregister`
--
ALTER TABLE `tblregister`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbltotal`
--
ALTER TABLE `tbltotal`
 ADD PRIMARY KEY (`tid`);

--
-- Indexes for table `tblupload1`
--
ALTER TABLE `tblupload1`
 ADD PRIMARY KEY (`id`), ADD KEY `sid` (`sid`), ADD KEY `sid_2` (`sid`), ADD KEY `sid_3` (`sid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `adminlogin`
--
ALTER TABLE `adminlogin`
MODIFY `adminid` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `merge`
--
ALTER TABLE `merge`
MODIFY `mid` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `subcategory`
--
ALTER TABLE `subcategory`
MODIFY `sid` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=54;
--
-- AUTO_INCREMENT for table `tbladdtocart`
--
ALTER TABLE `tbladdtocart`
MODIFY `aid` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=23;
--
-- AUTO_INCREMENT for table `tblbuy`
--
ALTER TABLE `tblbuy`
MODIFY `bid` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `tblregister`
--
ALTER TABLE `tblregister`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `tbltotal`
--
ALTER TABLE `tbltotal`
MODIFY `tid` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `tblupload1`
--
ALTER TABLE `tblupload1`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=92;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `merge`
--
ALTER TABLE `merge`
ADD CONSTRAINT `merge_ibfk_1` FOREIGN KEY (`id`) REFERENCES `categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `merge_ibfk_2` FOREIGN KEY (`sid`) REFERENCES `subcategory` (`sid`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `subcategory`
--
ALTER TABLE `subcategory`
ADD CONSTRAINT `subcategory_ibfk_1` FOREIGN KEY (`id`) REFERENCES `categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tblupload1`
--
ALTER TABLE `tblupload1`
ADD CONSTRAINT `tblupload1_ibfk_1` FOREIGN KEY (`sid`) REFERENCES `subcategory` (`sid`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
