<?php
session_start();
error_reporting(null);
 
 include("config.php");
  
 
?>
 
<?php	

$qry=mysql_query("select total from tbltotal where tbltotal.email='".$_SESSION["email"]."'");
while($r=mysql_fetch_assoc($qry))
{
	extract($r);
	?>
	<?php
	$y+=$r["total"]
	?>
	<?php
	}
	echo $a;

				
 $qry=mysql_query("select * from tbladdtocart,tblupload1");
 while($r=mysql_fetch_array($qry))
 {
	 extract($r);
	 $a=$r["pid"];
	 ?>
     
 <?php
 }
 ?>

 <table border=1>
 <tr><th>Product Name</th>
 <th>Product</th>
 <th>Quntity</th>
 <th>Price</th>
 <th>Total</th></tr>

 <?php

$qry1=mysql_query("select * from tbladdtocart,tblupload1 where tbladdtocart.email='".$_SESSION["email"]."' and tblupload1.id=tbladdtocart.pid");
 while($t=mysql_fetch_array($qry1))
 {
	 extract($t);
	 
	 
	 ?>
	
	  <td><?=$t["title"]?></td>
	 <td><img src="admin/<?=$t["path"]?> " height="200px" width="200px" /></td>
	 <td><?=$a=$t["pqty1"]?></td>
	 <td><?= $b=$t["pprice"]?></td>
	 

	 <?php
	 $d=$a;
	 
	 $f=$b;
	  
	 $c=$d * $f;
 if(isset($_POST['tot']))
{
extract($_POST);
	 
	 $q=mysql_query("insert into tbltotal(email,total)values('".$_SESSION["email"]."','$c')");
	 }
	 
	
	
	 
	 ?>
	 <td><?=$c?></td>
	 
	 
	

	 
	 </tr>

	 <?php
	 }
	 ?>
	 <tr>
	 
	 <td>
	  <a href="buynow.php"><input type="submit" class="btn btn-warning"  name="add" col-span=2 align="center" value="Add Shipping Details" /></a>
	  <form method="post">
	  <input type="submit" name="tot" value="total" />
	  
	  </form>
	 </td>
	 
	 </tr>
	 <tr>
	 <td align="center">
	   You Have to Pay: <?php echo $y; ?>
	 </td>
	 </tr>
</table>

