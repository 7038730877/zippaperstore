<?php
 error_reporting(null);
 session_start(); 
 include("head.php");
include("menu.php");
include("configi.php");
?>


 <?php
$a=$_GET["id"];


if(isset($_POST["add"]))
{
extract($_POST);
$q="insert into tbladdtocart(email,pid,pqty1)values('".$_SESSION["email"]."','$a','$txtqty')";
header("location:viewcart.php");

mysqli_query($con,$q);	
}
$qry=mysqli_query($con,"select * from tblupload1 where id=".$_GET['id']);
while($r=mysqli_fetch_assoc($qry))
{
	extract($r);
	?>
    




<div class="col-lg-4">
 <div class="panel panel-primary" >
                            <div class="panel-heading">
                              <h3 class="panel-title">
							<b> <?=$r["title"]?></b>
                             </h3>
                            </div>
                            
                              <div class="panel-body">
                              <form method="post">
                             
	<table >

<tr>
 <td><img src=" admin/<?=$r["path"]?>" height="250px" width="250px">
</td>
 


<td><br/><b><?=$r["pdescription"]?></b></td><br/>
</tR>
<tr>
<td><br/><b>Price-<?=$r["pprice"]?> <br/>Free Shipping Over Rs.300</b></td><br/>
</tr>
<tr>
<td>
Quantity:
</td>
<td>
<input type="number" name="txtqty" />
</td>
</tr>
<tr>
<td align="center"><input type="submit" class="btn btn-warning"  name="add" col-span=2 align="center" value="AddToCart" /></td>
</tr>

 </table>
 </form>
 </div>
 </div>
</div>
<?php
}
?>
<?php include("footer.php");?>
