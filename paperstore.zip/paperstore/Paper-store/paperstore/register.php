<?php
include("head.php")

?>
<?php

include("config.php");
include("mylib.php");
error_reporting(null);
$m=new mylib();

if(isset($_POST['btnreg']))
{
	extract($_POST);
	$qry=$m->runquery("insert into tblregister (fname,mnumber,email,password,repassword) values('$txtname','$txtmobile','$txtemail','$pwd','$pwd2')");
	header("location:login.php");
	
}
?>


  <div class="col-md-3 pull-center">
             
				 </div>
                </ul>
				<div class="logo pull-right">
                <ul class="previous">
				 
                	
					
                </ul>
				</div>
				
				
                <div class="clearfix"></div>
			   </div>
			   <div class="account_grid">
			   <div class="col-md-6 login-left">
			  	
			   
			   <style type="text/css">

  input:required:invalid, input:focus:invalid {
    background-image: url(boot/image/no.png);
    background-position: right top;
    background-repeat: no-repeat;
  }
  input:required:valid {
    background-image: url(boot/image/yes.png);
    background-position: right top;
    background-repeat: no-repeat;
  }


</style>

<?php $my_var = <<<EOD
<table class="table-condensed" align="center">
<div align="center">		
			<form method="post">
				  <div>
				  <tr>
				  <td>
					<span>Full Name<label>*</label></span>
				 </td>
				 <td>
					<input type="text" class="form-control" name="txtname"> 
				 </td>
				 </tr>
				  </div>
                  <div>
				  <tr>
				  <td>
					<span>Mobile<label>*</label></span>
			      </td>
				  <td>
					<input type="text" class="form-control" name="txtmobile"> 
				  </td>
				  </tr>
				  </div>
				  <div>
				  <tr>
				  <td>
					<span>E-Mail<label>*</label></span>
			      </td>
				  <td>
					<input type="email" class="form-control" name="txtemail"> 
				  </td>
				  </tr>
				  </div>
				  <div>
				  <tr>
				  <td>
					<span>Password<label>*</label></span>
				 </td>
				 <td>
					 <input type="password"  class="form-control"required title="Pls. Enter lowercaase/uppercase one number"  pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,}" onChange="form.pwd2.pattern = this.value;" name="pwd" /> 
				  </td>
				  </tr>
				  </div>
				  <div>
				  <tr>
				  <td>
					<span>Re-Entered Password<label>*</label></span>
				  </td>
				  <td>
				 <input type="password" name="pwd2" class="form-control" required title="Password Doesnot Match"  pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,}"   />
				 </td>
				 </tr>
				  </div>
<div>
				 <tr >
				 <td align="center">
				  <input type="submit" class="btn btn-warning" value="Registered" name="btnreg">
			    
				</td></tr>
				</div>
                
			    </form>
			 
	</div>		   
		
		</table>
	
EOD;
$m->createpanel("Registeration","$my_var","","col-md-9");
?>