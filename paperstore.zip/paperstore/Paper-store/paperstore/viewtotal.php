<?php
session_start();
include("config.php");
$qry=mysql_query("select total from tbltotal where tbltotal.email='".$_SESSION["email"]."'");
while($r=mysql_fetch_assoc($qry))
{
	extract($r);
	?>
	<?php
	$a+=$r["total"]
	?>
	<?php
	}
	echo $a;
?>
