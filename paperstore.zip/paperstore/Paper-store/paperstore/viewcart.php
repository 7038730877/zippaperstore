<?php
session_start();

 
 include("config.php");
  
 
?>
 
<?php					
 $qry=mysql_query("select * from tbladdtocart where email='".$_SESSION["email"]."'");
 while($r=mysql_fetch_array($qry))
 {
	 extract($r);
	 ?>
     <?=$a=$r["pid"]?>
 <?php
$qry1=mysql_query("select * from tblupload1 where id='$a'");
 while($t=mysql_fetch_array($qry1))
 {
	 extract($t);
	 
	 ?>
	  <?php
	if(isset($_POST['btnremove']))
{
extract($_POST);
$qry=mysql_query("delete from tbladdtocart  where pid='$a'");
echo $qry;
if($qry==1)
{
?>
<script>alert("Records deleted Sucessfully");</script>
<?php
}
}
?>	 
	                        <table border="1">
       <form method="post">
							  <tr>
                             <td><?=$t["title"]?></td>
							 
							 <td><a  href="viewcart.php?pid=<?=$r["pid"]?>">select</a></td>
							
					<td><input type="submit" name="btnremove" value="Remove X"</td>		
							 </tr>
							 
	

<tr>

 <td><img src=" admin/<?=$t["path"]?>" height="250px" width="250px">
</td>
 





<td><br/><b>Price-<?=$t["pprice"]?> <br/></b></td><br/>





 </table>


 </form>
 
<?php	
}

	
    
 }


?>
 <a href="continue.php"><input type="submit" class="btn btn-warning"  name="add" col-span=2 align="center" value="Continue" /></a>
 