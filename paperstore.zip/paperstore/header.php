<?php
error_reporting(null);
session_start();
 include("config.php");
 $q=mysql_query("select count(*) from tbladdtocart where email='".$_SESSION["email"]."'");
 
 

?>
<script src="ajax.js">
</script>

<div class="header">

<header id="header"><!--header-->
		<div class="header_top"  style="background-color:orange"><!--header_top-->
			<div class="container">
				<div class="row">
					<div class="col-sm-6">
					
						<div class="contactinfo">
							<ul class="nav nav-pills">
							
								<li><a href="#" ><i class="glyphicon glyphicon-phone"></i><font color="#FFFFFF"> +2 95 01 88 821</font></a></li>
								<li><a href="#"><i class="glyphicon glyphicon-envelope"></i> <font color="#FFFFFF">info@domain.com</font></a></li>
								
							</ul>
						</div>
					</div>
					<div class="col-sm-6">
						<div class="social-icons pull-right">
							<ul class="nav navbar-nav">
								<li><a href="index.php" ><img src="boot/logo/facebook.jpg" height="40" width="40" /></a></li>
								<li><a href="login.php"><img src="boot/logo/twitter.jpg" height="40" width="40" /></a></li>
								<li><a href="#"><img src="boot/logo/youtube.jpg" height="40" width="40"/></a></li>
								
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div><!--/header_top-->
		<div class="header-middle"  > <!--header-middle-->
			<div class="container">
				<div class="row">
					<div class="col-sm-4">
						<div class="logo pull-left">
							<a href="index.php" ></a>
						
							<h2><font style="border-bottom:groove" color="#FF0033">OnLine Stationary Store</font></h2>
						</div>
						
						
					</div>
					<div class="col-sm-8">
						<div class="shop-menu pull-right">
							<ul class="nav navbar-nav">
							
								<li><a href="#" ><i class="glyphicon glyphicon-user"></i> Account</a></li>
								<li><a href="#"><i class="glyphicon glyphicon-star"></i> Wishlist</a></li>
								<li><a href="checkout.html"><i class="glyphicon glyphicon-road"></i> Checkout</a></li>
								<li><a href="viewcart.php"><i class="glyphicon glyphicon-shopping-cart"></i> Cart<span class="badge"><?=$r?></span></a></li>
								
 
		                           <?php include("fancy.php");?>

								<li><a href="login.php" class="fancybox fancybox.iframe"><i class="glyphicon glyphicon-lock"></i> Login</a></li>
								<li><a href="logout.php"><i class="glyphicon glyphicon-lock"></i> Logout</a></li>
								
							</ul>
						</div>
						
					</div>
				</div>
			</div>
		</div><!--/header-middle-->
	
		<div class="header-bottom" style="background-color:" ><!--header-bottom-->
			<div class="container">
				<div class="row">
					<div class="col-sm-12">
						<div class="navbar-header">
							<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
								<span class="sr-only">Toggle navigation</span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
								<span class="icon-bar"></span>
							</button>
						</div>
						<div class="mainmenu pull-left">
							<ul class="nav navbar-nav collapse navbar-collapse">
								<li><a href="index.php" class="Active"><font face="Times New Roman, Times, serif" ><span style="color:orange" class="glyphicon glyphicon-home"><b> HOME</b></span></font></a></li>
								<li class="dropdown"><a href="#"><font face="Times New Roman, Times, serif" ><span style="color:orange"><b>OFFICE STATIONERY</b></span></font><i class="fa fa-angle-down"></i></a>
                                    <ul role="menu" class="sub-menu">
                                        <li><a href="desk.php">Desk Accessories</a></li>
										<li><a href="office.php">Office Files-Folders</a></li> 
										<li><a href="printer.php">Printer-Plotters Accessories</a></li> 
										
                                    </ul>
                                </li> 
								<li class="dropdown"><a href="#"><font face="Times New Roman, Times, serif" ><span style="color:orange"><b>WRITING SUPPLIES</b></span></font><i class="fa fa-angle-down"></i></a>
                                    <ul role="menu" class="sub-menu">
                                        <li><a href="correction.php">Correction Media</a></li>
										<li><a href="eraser.php">Erasers</a></li>
										<li><a href="high.php">HighLighters</a></li>
										<li><a href="pen2.php">Pens</a></li>
										<li><a href="pencil.php">Pencils</a></li>
										<li><a href="crayon.php">Crayons & Pastels</a></li>
										<li><a href="refil.php">Refil Leads</a></li>
                                    </ul>
                                </li> 
								<li class="dropdown"><a href="#"><font face="Times New Roman, Times, serif" ><span style="color:orange"><b>GREETINGS</b></span></font><i class="fa fa-angle-down"></i></a>
                                    <ul role="menu" class="sub-menu">
                                        <li><a href="birthday.php">Birthday Greeting</a></li>
										<li><a href="frien.php">Friendship Greeting</a></li>
										<li><a href="teacher.php">Teachers'Day Greeting </a></li>
										<li><a href="mother.php">Mother'sDay Greeting</a></li>
										<li><a href="father.php">Father'sDay Greeting</a></li>
										
                                    </ul>
                                </li> 
								
							<li class="dropdown"><a href="#"><font face="Times New Roman, Times, serif" ><span style="color:orange"><b>PAPERS</b></span></font><i class="fa fa-angle-down"></i></a>
                                    <ul role="menu" class="sub-menu">
                                        <li><a href="carbon.php">Carbon Paper</a></li>
										<li><a href="composit.php">Composition Books</a></li>
										<li><a href="computer.php">Computer Paper </a></li>
										<li><a href="sticky.php">Sticky Paper</a></li>
										<li><a href="envelop.php">Paper Envelops</a></li>
										
										
                                    </ul>
                                </li> 
								
							
							
							<div id="mydiv">
</div>
						</div>
						</div>
					</div>
					<div class="col-sm-3">
						
					</div>
				</div>
			</div>
		</div><!--/header-bottom-->
	</header><!--/header-->

		</div>
		