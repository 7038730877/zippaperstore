
<?php
session_start(); 
include("config.php");
include("mylib.php");
error_reporting(null);
$m=new mylib();

if(isset($_POST['btnlogin']))
{
	extract($_POST);
	$qry=$m->runquery("select * from tblregister where email='$email' and password='$password'");
	if(mysqli_num_rows($qry))
	{	
		$_SESSION["email"]=$email;
		
		?>
        <script>
     parent.$.fancybox.close();
	 window.location="index.php";
	 </script>
        <?php
    }	
	
}
?><?php
include("head.php");

?>

<script>
 function close()
 {
   jquery.fancybox.close();
 }
</script>


  <div class="col-md-3 pull-left">
                 <img src="boot/image/logo1.jpg" width="267" height="61" /> 
				 </div>
                </ul>
				<div class="logo pull-right">
                <ul class="previous">
				 
                	
					
                </ul>
				</div>
				
				
                <div class="clearfix"></div>
			   </div>
			   <div class="account_grid">
			   <div class="col-md-6 login-left">
			  	 <h3><font color="#0099FF">NEW CUSTOMERS</font></h3>
				 <p>By creating an account with our store, you will be able to move through the </p><p>checkout process faster, store multiple shipping addresses,</p> <p>view and track your orders in your account and more.</p>
				 
				   <?php include("fancy.php");?>
				 <a class="btn btn-warning" href="register.php"  class="fancybox fancybox.iframe" target="_parent" onclick="close">Create an Account</a>
			   </div>
			   <div class="col-md-3 login-right">
			   <li><a href="index.php" onclick="close()">Back to Previous Page</a></li>
			  	<h3 ><font color="#0099FF">REGISTERED CUSTOMERS</font></h3>
				<p>If you have an account with us, please log in.</p>
				<form method="post">
				<table class="table-condensed">
				  <div>
				  <tr>
				  <td>
					<span>Email Address<label>*</label></span>
					</td>
					<td>
					<input type="text" class="form-control" name="email">
					</td>
				</tr>	 
				  </div>
				  <div>
				  <tr>
				  <td>
					<span>Password<label>*</label></span>
					</td>
					<td>
					<input type="password" class="form-control" name="password"> 
					</td>
					</tr>
				  </div>
				  <div>
				  <tr>
				  <td>
				  <a class="forgot" href="#">Forgot Your Password?</a>
				  </td>
				  <td>
				  <input type="submit"  class="btn btn-warning" value="Login" name="btnlogin"  >
				  </td>
				  </tr>
				  </div>
			    </table>
				</form>
			   </div>	
			   <div class="clearfix"> </div>
			 </div>
		   </div>
		  </div>
	     </div>
	    </div>
	    </div>
		