<html>
<style>
.wrapper
{
margin-left:15%;
margin-right:15%;
}
</style>
<head>
<link href="mystyle.css" rel="stylesheet">
<?php include("head_fancy.php");?>
<?php include("configi.php");?>
<?php include("head.php");?>
<?php include("bg.php");?>
<style>
img
{
	float:right;
}
</style>
<script src="lazy.js"></script>

<title>
</title>
</head>
<body>
<?php include("header.php");?>
<div class="mydiv">
<div class="row">


<?php
$qry=mysqli_query($con,"select * from tblupload1 where sid=50 order by id desc limit 3");
$total=mysqli_num_rows($qry);
if($total>0)
{
while($r=mysqli_fetch_assoc($qry))
{
	$id=$r["id"];
   ?>
   <div class="wrapper">
   <div class="col-md-4">
   <div class="panel panel-warning" style="height:400px" > 
            <div class="panel-heading">
              <h3 class="panel-title" style="color:orange"><?=$r["title"]?></h3>
            </div>
            <div class="panel-body">
             
           
   <div class="list_item" id="<?=$r["id"]?>">
   <table>
   <Tr>
   <td>
   
  <a href="view.php"> <img src=" admin/<?=$r["path"]?>" height="200px" width="200px"></a>
   </td>
  <tr>
   
   <td><br/><b>Price-<?=$r["pprice"]?></b></td><br/>

    
   
   
   
   
  
   </tr>
   <tr>
   <td>
   
    <a href="view.php?id=<?=$r["id"]?>"  class="fancybox fancybox.iframe"><input type="submit" class="btn btn-warning" col-span=2 align="center" value="View" /></a>


   </td>
   </tr>
   
    
   </table>
  
    </div>
          </div>
   </div>
   </div>
   </div>
<?php
}
?>
</div>
<div class="show_more_main" id="show_more_main<?php echo $id; ?>">
                <span id="<?php echo $id; ?>" class="show_more" title="Load more posts">Show more</span>
                <span class="loding" style="display: none;"><span class="loding_txt">Loading...</span></span>
            </div>

<?php
}

?>



</div>

</body>
</html>