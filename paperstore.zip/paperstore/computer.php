 distribution
2017-07-19 22:23:04 a1c InnoDB: Warning: Using innodb_additional_mem_pool_size is DEPRECATED. This option may be removed in future releases, together with the option innodb_use_sys_malloc and with the InnoDB's internal memory allocator.
2017-07-19 22:23:04 2588 [Note] InnoDB: Using mutexes to ref count buffer pool pages
2017-07-19 22:23:04 2588 [Note] InnoDB: The InnoDB memory heap is disabled
2017-07-19 22:23:04 2588 [Note] InnoDB: Mutexes and rw_locks use Windows interlocked functions
2017-07-19 22:23:04 2588 [Note] InnoDB: Memory barrier is not used
2017-07-19 22:23:04 2588 [Note] InnoDB: Compressed tables use zlib 1.2.3
2017-07-19 22:23:05 2588 [Note] InnoDB: Using generic crc32 instructions
2017-07-19 22:23:05 2588 [Note] InnoDB: Initializing buffer pool, size = 16.0M
2017-07-19 22:23:05 2588 [Note] InnoDB: Completed initialization of buffer pool
2017-07-19 22:23:05 2588 [Note] InnoDB: Highest supported file format is Barracuda.
2017-07-19 22:23:05 2588 [Note] InnoDB: The log sequence numbers 1835037 and 1835037 in ibdata files do not match the log sequence number 6747850 in the ib_logfiles!
2017-07-19 22:23:05 2588 [Note] InnoDB: Database was not shutdown normally!
2017-07-19 22:23:05 2588 [Note] InnoDB: Starting crash recovery.
2017-07-19 22:23:05 2588 [Note] InnoDB: Reading tablespace information from the .ibd files...
2017-07-19 22:23:06 2588 [Note] InnoDB: Restoring possible half-written data pages 
2017-07-19 22:23:06 2588 [Note] InnoDB: from the doublewrite buffer...
2017-07-19 22:23:23 2588 [Note] InnoDB: 128 rollback segment(s) are active.
2017-07-19 22:23:23 2588 [Note] InnoDB: Waiting for purge to start
2017-07-19 22:23:23 2588 [Note] InnoDB:  Percona XtraDB (http://www.percona.com) 5.6.28-76.1 started; log sequence number 6747850
2017-07-19 22:23:24 1884 [Note] InnoDB: Dumping buffer pool(s) not yet started
2017-07-19 22:23:24 2588 [Note] Plugin 'FEEDBACK' is disabled.
